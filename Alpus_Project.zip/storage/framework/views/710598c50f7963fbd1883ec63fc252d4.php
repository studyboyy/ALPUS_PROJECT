<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="utf-8">
    <title>Dokumen <?php echo e($categoryLabel); ?></title>
    <style>
        body {
            font-family: DejaVu Sans, sans-serif;
            color: #0f172a;
            font-size: 12px;
            line-height: 1.5;
            margin: 24px;
        }

        h1 {
            margin: 0 0 6px;
            font-size: 24px;
        }

        .muted {
            color: #64748b;
        }

        .box {
            border: 1px solid #dbe5f2;
            border-radius: 10px;
            padding: 12px;
            margin-top: 10px;
        }

        .tag {
            display: inline-block;
            margin-top: 8px;
            padding: 4px 8px;
            border-radius: 999px;
            background: #eff6ff;
            color: #1d4ed8;
            font-size: 10px;
        }
    </style>
</head>

<body>
    <h1>Dokumen Pendukung</h1>
    <p class="muted">Kategori: <?php echo e($categoryLabel); ?></p>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
        <div class="box">
            <strong><?php echo e($document->title); ?></strong><br>
            <span class="muted"><?php echo e($document->description); ?></span><br>
            <span class="tag"><?php echo e($document->category); ?></span>
            <div style="margin-top: 8px;">File: <?php echo e($document->file_name ?: 'Dokumen'); ?></div>
            <div class="muted"><?php echo e($document->file_url); ?></div>
        </div>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
</body>

</html>
<?php /**PATH C:\Users\Administrator\Herd\alpus_project\resources\views/pdf/document-category.blade.php ENDPATH**/ ?>