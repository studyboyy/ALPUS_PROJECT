<div class="grid gap-4 lg:grid-cols-3">
    <article class="section-box rounded-2xl p-6 lg:col-span-2">
        <h2 class="display-font text-4xl leading-tight">Profil Program Studi</h2>
        <p class="mt-3 text-sm text-(--muted)">Halaman ini menampilkan identitas program studi: sejarah, visi misi,
            struktur organisasi, SDM, serta capaian strategis yang mendukung akreditasi dan daya saing lulusan.</p>

        <div class="mt-6 grid gap-4 sm:grid-cols-2">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($profileSections)): ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $profileSections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <?php
                        $colors = \App\Models\ProfileSection::getColorClasses($section['color_class'] ?? 'blue');
                    ?>
                    <a wire:navigate.hover href="<?php echo e(route('profil.detail', ['slug' => $section['slug']])); ?>"
                        class="group rounded-xl border-l-4 <?php echo e($colors['top-border']); ?> border-slate-200 bg-slate-50 p-4 transition-all hover:-translate-y-0.5 hover:shadow-md">
                        <h3 class="font-semibold group-hover:<?php echo e($colors['text']); ?>"><?php echo e($section['title']); ?></h3>
                        <p class="mt-2 text-sm text-(--muted) group-hover:text-slate-700">
                            <?php echo e(Str::limit($section['summary'], 50, '...')); ?></p>
                        <span
                            class="mt-3 inline-block rounded-full <?php echo e($colors['bg-light']); ?> px-3 py-1 text-xs font-semibold <?php echo e($colors['text']); ?>">
                            Lihat Detail →
                        </span>
                    </a>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            <?php else: ?>
                <div class="rounded-xl border border-(--line) bg-slate-50 p-4 sm:col-span-2">
                    <p class="text-sm text-(--muted)">Data profil sedang dimuat...</p>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </article>

    <article class="section-box rounded-2xl p-6">
        <p class="text-xs font-semibold uppercase tracking-[0.16em] text-(--olive)">Highlight Cepat</p>
        <ul class="mt-4 space-y-4 text-sm">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $highlightItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <li class="rounded-xl border border-(--line) bg-slate-50 p-3"><strong><?php echo e($item['label']); ?>:</strong>
                    <?php echo e($item['value']); ?></li>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </ul>
    </article>
</div>
<?php /**PATH C:\Users\Administrator\Herd\alpus_project\resources\views/livewire/pages/profil-page.blade.php ENDPATH**/ ?>