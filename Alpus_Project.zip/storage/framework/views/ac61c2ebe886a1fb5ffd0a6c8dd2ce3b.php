<section class="section-box rounded-2xl p-6 md:p-8" x-data="{ open: false, image: '', title: '' }" @keydown.escape.window="open = false">
    <div class="flex flex-wrap items-center justify-between gap-3">
        <div>
            <h2 class="display-font text-4xl leading-tight">Galeri Kegiatan</h2>
            <p class="mt-3 text-sm text-(--muted)">Dokumentasi lengkap kegiatan akademik, kemahasiswaan, pengabdian
                masyarakat,
                dan kolaborasi institusional.</p>
        </div>
        <span class="rounded-full bg-indigo-50 px-3 py-1 text-xs font-semibold text-indigo-700">Total foto:
            <?php echo e(count($galleryItems)); ?></span>
    </div>

    <div class="mt-5 flex flex-wrap gap-2">
        <button type="button" wire:click="pilihKategori('Semua')"
            class="rounded-full px-4 py-2 text-xs font-semibold <?php echo e($kategoriDipilih === 'Semua' ? 'bg-(--accent) text-white' : 'border border-(--line) bg-white text-slate-700'); ?>">Semua</button>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $kategoriList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <div class="flex items-center overflow-hidden rounded-full border border-(--line) bg-white">
                <button type="button" wire:click="pilihKategori('<?php echo e($kategori); ?>')"
                    class="px-4 py-2 text-xs font-semibold <?php echo e($kategoriDipilih === $kategori ? 'bg-(--accent) text-white' : 'text-slate-700'); ?>"><?php echo e($kategori); ?></button>
                <a wire:navigate.hover
                    href="<?php echo e(route('galeri.category', ['kategori' => $kategoriSlugMap[$kategori] ?? Illuminate\Support\Str::slug($kategori)])); ?>"
                    class="border-l border-(--line) px-3 py-2 text-[11px] font-semibold text-slate-500 hover:bg-slate-50">URL</a>
            </div>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
    </div>

    <div class="mt-6 space-y-8">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = collect($galleryItems)->groupBy(fn($item) => data_get($item, 'category', 'Galeri')); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <section>
                <div class="mb-4 flex items-center gap-3">
                    <h3 class="text-xl font-bold"><?php echo e($category); ?></h3>
                    <span
                        class="rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-600"><?php echo e($items->count()); ?>

                        foto</span>
                    <a wire:navigate.hover
                        href="<?php echo e(route('galeri.category', ['kategori' => $kategoriSlugMap[$category] ?? Illuminate\Support\Str::slug($category)])); ?>"
                        class="text-xs font-semibold text-(--accent) hover:underline">Buka kategori ini</a>
                </div>
                <div class="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <article
                            class="group overflow-hidden rounded-2xl border border-(--line) bg-white shadow-sm transition hover:-translate-y-1 hover:shadow-lg">
                            <button type="button" class="block w-full text-left"
                                @click="image = <?php echo \Illuminate\Support\Js::from(data_get($item, 'image_url'))->toHtml() ?>; title = <?php echo \Illuminate\Support\Js::from(data_get($item, 'title'))->toHtml() ?>; open = true">
                                <img src="<?php echo e(data_get($item, 'image_url')); ?>" alt="<?php echo e(data_get($item, 'title')); ?>"
                                    class="h-56 w-full object-cover transition duration-300 group-hover:scale-105">
                            </button>
                            <div class="px-4 py-3">
                                <p class="text-sm font-semibold"><?php echo e(data_get($item, 'title')); ?></p>
                            </div>
                        </article>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </div>
            </section>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(count($galleryItems) === 0): ?>
            <div class="rounded-2xl border border-dashed border-slate-300 bg-slate-50 p-6 text-sm text-slate-500">
                Belum ada foto pada kategori ini.
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>

    <div x-show="open" x-transition.opacity class="fixed inset-0 z-50 bg-slate-900/80 p-4" style="display: none;"
        @click.self="open = false">
        <div class="mx-auto mt-8 max-w-5xl overflow-hidden rounded-2xl bg-white shadow-2xl">
            <img :src="image" :alt="title" class="max-h-[75vh] w-full object-contain bg-slate-100">
            <div class="flex items-center justify-between px-5 py-3">
                <p class="text-sm font-semibold text-slate-800" x-text="title"></p>
                <button type="button" @click="open = false"
                    class="rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50">Tutup</button>
            </div>
        </div>
    </div>
</section>
<?php /**PATH C:\Users\Administrator\Herd\alpus_project\resources\views/livewire/pages/galeri-page.blade.php ENDPATH**/ ?>