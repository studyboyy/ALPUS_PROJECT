<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="utf-8">
    <title>Galeri <?php echo e($categoryLabel); ?></title>
    <style>
        body {
            font-family: DejaVu Sans, sans-serif;
            color: #0f172a;
            font-size: 12px;
            line-height: 1.5;
            margin: 24px;
        }

        h1 {
            margin: 0 0 6px;
            font-size: 24px;
        }

        .muted {
            color: #64748b;
        }

        .grid {
            width: 100%;
            border-collapse: collapse;
            margin-top: 14px;
        }

        .grid th,
        .grid td {
            border: 1px solid #dbe5f2;
            padding: 8px;
            text-align: left;
        }

        .grid th {
            background: #f8fafc;
        }
    </style>
</head>

<body>
    <h1>Galeri Kegiatan</h1>
    <p class="muted">Kategori: <?php echo e($categoryLabel); ?></p>

    <table class="grid">
        <thead>
            <tr>
                <th>Judul</th>
                <th>Kategori</th>
                <th>Gambar</th>
            </tr>
        </thead>
        <tbody>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $galleryItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <tr>
                    <td><?php echo e(data_get($item, 'title')); ?></td>
                    <td><?php echo e(data_get($item, 'category')); ?></td>
                    <td><?php echo e(data_get($item, 'image_url')); ?></td>
                </tr>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </tbody>
    </table>
</body>

</html>
<?php /**PATH C:\Users\Administrator\Herd\alpus_project\resources\views/pdf/gallery-category.blade.php ENDPATH**/ ?>