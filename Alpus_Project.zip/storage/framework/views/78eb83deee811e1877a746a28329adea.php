<div class="grid gap-4 lg:grid-cols-2">
    <article class="section-box rounded-2xl p-6 lg:col-span-2">
        <div class="flex flex-wrap items-center justify-between gap-3">
            <h2 class="display-font text-4xl leading-tight">Data dan Statistik</h2>
            <?php
                $tahunStatistikAwal = collect($daftarTahun)->take(6)->all();
                $tahunStatistikLanjutan = collect($daftarTahun)->slice(6)->all();
            ?>
            <div class="space-y-2">
                <div class="flex flex-wrap gap-2">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $tahunStatistikAwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tahun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <button type="button" wire:click="pilihTahun(<?php echo e($tahun); ?>)"
                            class="rounded-full px-4 py-2 text-xs font-semibold <?php echo e($statAktif && $statAktif->year === $tahun ? 'bg-(--accent) text-white' : 'border border-(--line) bg-white'); ?>"><?php echo e($tahun); ?></button>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(count($tahunStatistikLanjutan) > 0): ?>
                    <details>
                        <summary class="cursor-pointer text-xs font-semibold text-(--muted)">Lihat semua tahun</summary>
                        <div class="mt-2 flex flex-wrap gap-2">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $tahunStatistikLanjutan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tahun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <button type="button" wire:click="pilihTahun(<?php echo e($tahun); ?>)"
                                    class="rounded-full px-4 py-2 text-xs font-semibold <?php echo e($statAktif && $statAktif->year === $tahun ? 'bg-(--accent) text-white' : 'border border-(--line) bg-white'); ?>"><?php echo e($tahun); ?></button>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </div>
                    </details>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>

        <div class="mt-5 grid gap-3 md:grid-cols-4">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $statAktif?->kpi ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <div class="rounded-xl border border-(--line) bg-slate-50 p-4">
                    <p class="text-xs text-(--muted)"><?php echo e(data_get($item, 'label')); ?></p>
                    <p class="mt-1 text-2xl font-bold">
                        <?php echo e(number_format((float) data_get($item, 'value', 0), (int) data_get($item, 'decimals', 0), ',', '.')); ?>

                    </p>
                </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>
    </article>

    <article class="section-box rounded-2xl p-6">
        <div class="flex flex-wrap items-center justify-between gap-2">
            <p class="text-sm font-semibold">Tren Indikator Utama</p>
            <div class="flex items-center gap-2">
                <button type="button" wire:click="pilihTrendMode('year')"
                    class="rounded-full px-3 py-1 text-[11px] font-semibold transition <?php echo e(data_get($trendVisual, 'trendMode', 'year') === 'year' ? 'bg-(--accent) text-white' : 'border border-(--line) bg-white text-(--muted)'); ?>">Per
                    Tahun</button>
                <button type="button" wire:click="pilihTrendMode('all')"
                    class="rounded-full px-3 py-1 text-[11px] font-semibold transition <?php echo e(data_get($trendVisual, 'trendMode', 'year') === 'all' ? 'bg-(--accent) text-white' : 'border border-(--line) bg-white text-(--muted)'); ?>">Semua
                    Tahun</button>
            </div>
        </div>
        <div class="mt-4 rounded-xl border border-(--line) bg-slate-50 p-4">
            <p class="mb-3 text-[11px] font-semibold uppercase tracking-[0.14em] text-(--muted)">
                <?php echo e(data_get($trendVisual, 'rangeLabel', 'Ringkasan data')); ?></p>
            <svg viewBox="0 0 340 170" class="h-44 w-full">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = data_get($trendVisual, 'yTicks', []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tick): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <line x1="34" y1="<?php echo e(data_get($tick, 'y')); ?>" x2="310"
                        y2="<?php echo e(data_get($tick, 'y')); ?>" stroke="#dbe5f2" stroke-width="1" />
                    <text x="28" y="<?php echo e(data_get($tick, 'y') + 3); ?>" text-anchor="end" font-size="9"
                        fill="#64748b"><?php echo e(data_get($tick, 'label')); ?></text>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

                <polyline points="<?php echo e(data_get($trendVisual, 'mahasiswa', '')); ?>" fill="none" stroke="#1d4ed8"
                    stroke-width="4" />
                <polyline points="<?php echo e(data_get($trendVisual, 'ipk', '')); ?>" fill="none" stroke="#0f766e"
                    stroke-width="4" />
                <polyline points="<?php echo e(data_get($trendVisual, 'publikasi', '')); ?>" fill="none" stroke="#ea580c"
                    stroke-width="3" stroke-dasharray="6 5" />
                <polyline points="<?php echo e(data_get($trendVisual, 'dosen', '')); ?>" fill="none" stroke="#fb923c"
                    stroke-width="3" />
                <polyline points="<?php echo e(data_get($trendVisual, 'progressYtd', '')); ?>" fill="none" stroke="#7c3aed"
                    stroke-width="3" stroke-dasharray="3 3" />
                <circle cx="<?php echo e(data_get($trendVisual, 'lastX', 310)); ?>"
                    cy="<?php echo e(data_get($trendVisual, 'mahasiswaLastY', 90)); ?>" r="5" fill="#1d4ed8" />
                <circle cx="<?php echo e(data_get($trendVisual, 'lastX', 310)); ?>"
                    cy="<?php echo e(data_get($trendVisual, 'ipkLastY', 96)); ?>" r="5" fill="#0f766e" />
                <circle cx="<?php echo e(data_get($trendVisual, 'lastX', 310)); ?>"
                    cy="<?php echo e(data_get($trendVisual, 'publikasiLastY', 102)); ?>" r="4" fill="#ea580c" />
                <circle cx="<?php echo e(data_get($trendVisual, 'lastX', 310)); ?>"
                    cy="<?php echo e(data_get($trendVisual, 'dosenLastY', 108)); ?>" r="4" fill="#fb923c" />
                <circle cx="<?php echo e(data_get($trendVisual, 'lastX', 310)); ?>"
                    cy="<?php echo e(data_get($trendVisual, 'progressLastY', 96)); ?>" r="4" fill="#7c3aed" />

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = data_get($trendVisual, 'yearTicks', []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tick): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <text x="<?php echo e(data_get($tick, 'x')); ?>" y="147" text-anchor="middle" font-size="9"
                        fill="#64748b"><?php echo e(data_get($tick, 'year')); ?></text>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </svg>
            <div class="mt-2 flex flex-wrap gap-4 text-xs text-(--muted)">
                <span>Garis biru: Mahasiswa</span>
                <span>Garis hijau: IPK</span>
                <span>Garis oranye putus: Publikasi</span>
                <span>Garis oranye terang: Dosen Tetap</span>
                <span>Garis ungu putus: Progres Kinerja YTD (%)</span>
            </div>
        </div>
    </article>

    <article class="section-box rounded-2xl p-6">
        <p class="text-sm font-semibold">Capaian Persentase</p>
        <div class="mt-6 space-y-4 text-sm">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $statAktif?->capaian ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <div>
                    <div class="mb-1 flex justify-between">
                        <span><?php echo e(data_get($item, 'label')); ?></span><span><?php echo e(number_format((float) data_get($item, 'percent', 0), 0, ',', '.')); ?>%</span>
                    </div>
                    <div class="h-2 overflow-hidden rounded-full bg-[#eadfce]"><span
                            class="block h-full rounded-full bg-[linear-gradient(90deg,var(--accent),#ef8d44)]"
                            style="width: <?php echo e(max(0, min(100, (float) data_get($item, 'percent', 0)))); ?>%"></span>
                    </div>
                </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>
    </article>

    <article class="section-box rounded-2xl p-6 lg:col-span-2">
        <div class="flex flex-wrap items-center justify-between gap-2">
            <p class="text-sm font-semibold">Statistik Kinerja Tahunan Berjalan (Dinamis)</p>
            <span class="rounded-full bg-sky-50 px-3 py-1 text-[11px] font-semibold text-sky-700">YTD s.d.
                <?php echo e(data_get($kinerjaTahunanBerjalan, 'monthLabel', '-')); ?>

                <?php echo e(data_get($kinerjaTahunanBerjalan, 'year', $tahunDipilih)); ?></span>
        </div>
        <div class="mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-4">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = data_get($kinerjaTahunanBerjalan, 'items', []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <?php
                    $status = data_get($item, 'status', 'danger');
                    $statusClass = match ($status) {
                        'success' => 'from-emerald-500 to-teal-600',
                        'warning' => 'from-amber-500 to-orange-600',
                        default => 'from-rose-500 to-pink-600',
                    };
                    $progress = (float) data_get($item, 'progress', 0);
                    $decimals = (int) data_get($item, 'decimals', 0);
                ?>
                <div class="rounded-xl border border-(--line) bg-slate-50 p-4">
                    <p class="text-xs font-semibold uppercase tracking-[0.12em] text-slate-500">
                        <?php echo e(data_get($item, 'label')); ?></p>
                    <p class="mt-2 text-lg font-bold text-slate-800">
                        <?php echo e(number_format((float) data_get($item, 'realisasi', 0), $decimals, ',', '.')); ?>

                        <span class="text-xs font-medium text-slate-500">/
                            <?php echo e(number_format((float) data_get($item, 'target', 0), $decimals, ',', '.')); ?></span>
                    </p>
                    <div class="mt-3 h-2 overflow-hidden rounded-full bg-slate-200">
                        <span class="block h-full rounded-full bg-linear-to-r <?php echo e($statusClass); ?>"
                            style="width: <?php echo e(max(0, min(100, $progress))); ?>%"></span>
                    </div>
                    <div class="mt-2 flex items-center justify-between text-[11px] text-(--muted)">
                        <span>Progres <?php echo e(number_format($progress, 1, ',', '.')); ?>%</span>
                        <span>Forecast
                            <?php echo e(number_format((float) data_get($item, 'forecast', 0), $decimals, ',', '.')); ?></span>
                    </div>
                </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty(data_get($kinerjaTahunanBerjalan, 'updatedAt'))): ?>
            <p class="mt-3 text-[11px] text-(--muted)">Pembaruan terakhir:
                <?php echo e(data_get($kinerjaTahunanBerjalan, 'updatedAt')); ?></p>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </article>

    <article class="section-box rounded-2xl p-6 lg:col-span-2">
        <div class="grid gap-4 md:grid-cols-2 xl:grid-cols-5">
            <div class="rounded-xl border border-(--line) bg-slate-50 p-4">
                <p class="text-xs font-semibold uppercase tracking-[0.14em] text-slate-500">Jumlah Mahasiswa Aktif</p>
                <p class="mt-2 text-xl font-bold text-slate-800">
                    <?php echo e(number_format((float) data_get($statAktif?->kpi, '0.value', 0), 0, ',', '.')); ?></p>
            </div>
            <div class="rounded-xl border border-(--line) bg-slate-50 p-4">
                <p class="text-xs font-semibold uppercase tracking-[0.14em] text-slate-500">Lulusan & Tracer Study</p>
                <p class="mt-2 text-xl font-bold text-slate-800">
                    <?php echo e(number_format((float) data_get($statAktif?->capaian, '1.percent', 0), 0, ',', '.')); ?>%</p>
            </div>
            <div class="rounded-xl border border-(--line) bg-slate-50 p-4">
                <p class="text-xs font-semibold uppercase tracking-[0.14em] text-slate-500">Publikasi Ilmiah</p>
                <p class="mt-2 text-xl font-bold text-slate-800">
                    <?php echo e(number_format((float) data_get($statAktif?->kpi, '3.value', 0), 0, ',', '.')); ?></p>
            </div>
            <div class="rounded-xl border border-(--line) bg-slate-50 p-4">
                <p class="text-xs font-semibold uppercase tracking-[0.14em] text-slate-500">Kegiatan Dosen & Mahasiswa
                </p>
                <p class="mt-2 text-xl font-bold text-slate-800">
                    <?php echo e(number_format((float) data_get($statAktif?->capaian, '3.percent', 0), 0, ',', '.')); ?>%</p>
            </div>
            <div class="rounded-xl border border-(--line) bg-slate-50 p-4">
                <p class="text-xs font-semibold uppercase tracking-[0.14em] text-slate-500">Program Aktif</p>
                <p class="mt-2 text-xl font-bold text-slate-800"><?php echo e($programCount); ?></p>
            </div>
        </div>
    </article>
</div>
<?php /**PATH C:\Users\Administrator\Herd\alpus_project\resources\views/livewire/pages/statistik-page.blade.php ENDPATH**/ ?>