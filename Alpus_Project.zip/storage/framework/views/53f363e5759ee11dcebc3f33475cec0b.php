<section class="section-box rounded-2xl p-6 md:p-8">
    <div class="grid gap-6 lg:grid-cols-2">
        <div>
            <h2 class="display-font text-4xl leading-tight">Kontak dan Umpan Balik</h2>
            <p class="mt-3 text-sm text-(--muted)">Silakan kirim umpan balik untuk peningkatan layanan akademik dan tata
                kelola Program Studi.</p>

            <div class="mt-5 space-y-3 text-sm text-(--muted)">
                <div class="rounded-xl border border-(--line) bg-slate-50 p-3"><strong>Email:</strong>
                    <?php echo e($homeContent['contact_email']); ?></div>
                <div class="rounded-xl border border-(--line) bg-slate-50 p-3"><strong>Telepon:</strong>
                    <?php echo e($homeContent['contact_phone']); ?></div>
                <div class="rounded-xl border border-(--line) bg-slate-50 p-3"><strong>WhatsApp:</strong>
                    <a href="https://wa.me/<?php echo e(preg_replace('/\D+/', '', $homeContent['contact_whatsapp'])); ?>"
                        target="_blank" rel="noreferrer"
                        class="text-(--accent) hover:underline"><?php echo e($homeContent['contact_whatsapp']); ?></a>
                </div>
                <div class="rounded-xl border border-(--line) bg-slate-50 p-3"><strong>Alamat:</strong>
                    <?php echo e($homeContent['contact_address']); ?></div>
                <div class="rounded-xl border border-(--line) bg-slate-50 p-3"><strong>Media Sosial:</strong>
                    <div class="mt-2 flex flex-wrap gap-2">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $homeContent['contact_social_links']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($social['url'])): ?>
                                <a href="<?php echo e($social['url']); ?>" target="_blank" rel="noreferrer"
                                    class="rounded-full bg-white px-3 py-1 text-xs font-semibold text-(--accent) ring-1 ring-(--line)"><?php echo e($social['label']); ?></a>
                            <?php else: ?>
                                <span
                                    class="rounded-full bg-white px-3 py-1 text-xs font-semibold text-(--accent) ring-1 ring-(--line)"><?php echo e($social['label']); ?></span>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="mt-5 overflow-hidden rounded-xl border border-(--line)">
                <iframe title="Lokasi Prodi" class="h-56 w-full" src="<?php echo e($homeContent['contact_map_embed_url']); ?>"
                    loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
        </div>

        <form wire:submit="kirimUmpanBalik" class="grid gap-3 rounded-2xl border border-(--line) bg-slate-50 p-5">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session()->has('contact_status')): ?>
                <div class="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-700">
                    <?php echo e(session('contact_status')); ?>

                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <input wire:model.defer="feedbackName" type="text" placeholder="Nama"
                class="rounded-xl border border-(--line) bg-white px-4 py-3 text-sm outline-none focus:border-(--accent)">
            <input wire:model.defer="feedbackEmail" type="email" placeholder="Email"
                class="rounded-xl border border-(--line) bg-white px-4 py-3 text-sm outline-none focus:border-(--accent)">
            <input wire:model.defer="feedbackSubject" type="text" placeholder="Subjek"
                class="rounded-xl border border-(--line) bg-white px-4 py-3 text-sm outline-none focus:border-(--accent)">
            <textarea wire:model.defer="feedbackMessage" rows="4" placeholder="Pesan / Saran"
                class="rounded-xl border border-(--line) bg-white px-4 py-3 text-sm outline-none focus:border-(--accent)"></textarea>
            <button type="submit" class="rounded-full bg-(--accent) px-5 py-3 text-sm font-semibold text-white">Kirim
                Umpan Balik</button>
        </form>
    </div>
</section>
<?php /**PATH C:\Users\Administrator\Herd\alpus_project\resources\views/livewire/pages/kontak-page.blade.php ENDPATH**/ ?>